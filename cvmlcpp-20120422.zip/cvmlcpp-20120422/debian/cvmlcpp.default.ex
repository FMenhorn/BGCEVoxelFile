# Defaults for cvmlcpp initscript
# sourced by /etc/init.d/cvmlcpp
# installed at /etc/default/cvmlcpp by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
