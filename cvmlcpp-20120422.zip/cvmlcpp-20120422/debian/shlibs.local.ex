libcvmlcpp 20101115 cvmlcpp (>> 20101115-0), cvmlcpp (<< 20101115-99)
